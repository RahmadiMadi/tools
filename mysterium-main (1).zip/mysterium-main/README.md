#  ­  ­  ­  ­  ­ **𝙈 ­  ­  ­  ­  ­  ­  ­ 𝙔 ­  ­  ­  ­  ­  ­  ­ 𝙎 ­  ­  ­  ­  ­  ­  ­ 𝙏 ­  ­  ­  ­  ­  ­  ­ 𝙀 ­  ­  ­  ­  ­  ­  ­ 𝙍 ­  ­  ­  ­  ­  ­  ­ 𝙄 ­  ­  ­  ­  ­  ­  ­ 𝙐 ­  ­  ­  ­  ­  ­  ­ 𝙈**
![mysterium_logo (1)](https://user-images.githubusercontent.com/81310818/132258721-dc02bb73-772c-4530-a636-4daffbcdc23a.png)
```
Mysterium has been entirely made by @venaxyt, helped by @IDRALOU.
```
```
Mysterium usage:
- If the file to be inspect extension is ".py" or ".pyc": You only have to drag it into Mysterium.
- If the file to be inspect extension is ".exe": If you don't know how to decompile an executable Python file, so you can wait for next Mysterium updates.
- If the file to be inspect is obfuscated with Pyarmor: You put the Python file and the pytransform folder into a zip file, drag it into Mysterium and input the Python file name.
```
![mysterium](https://user-images.githubusercontent.com/81310818/132141525-0bfb0f6e-a0d4-4770-8861-97622160baff.PNG)
> ### **YouTube Tutorial (FR): https://www.youtube.com/watch?v=1idhXNeluCc**<br>
> ### **Mysterium official Discord server: discord.gg/mysterium | https://discord.gg/ccufCedf44**<br>
> ## **V  ­  ­ E  ­  ­ N  ­  ­ A  ­  ­ X**
