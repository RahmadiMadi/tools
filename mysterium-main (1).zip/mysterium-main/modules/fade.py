print("import fade")

def blackwhite(text):
    print(f'fade.blackwhite(text="{text}")')
    return text

def purplepink(text):
    print(f'fade.purplepink(text="{text}")')
    return text

def greenblue(text):
    print(f'fade.greenblue(text="{text}")')
    return text

def pinkred(text):
    print(f'fade.pinkred(text="{text}")')
    return text

def purpleblue(text):
    print(f'fade.purpleblue(text="{text}")')
    return text

def water(text):
    print(f'fade.water(text="{text}")')
    return text

def fire(text):
    print(f'fade.fire(text="{text}")')
    return text

def brazil(text):
    print(f'fade.brazil(text="{text}")')
    return text

def random(text):
    print(f'fade.random(text="{text}")')
    return text