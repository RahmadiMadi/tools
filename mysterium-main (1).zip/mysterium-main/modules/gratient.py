print("import gratient")

def black(text):
    print(f'gratient.black(text="{text}")')
    return text

def green(text):
    print(f'gratient.green(text="{text}")')
    return text

def blue(text):
    print(f'gratient.blue(text="{text}")')
    return text

def purple(text):
    print(f'gratient.purple(text="{text}")')
    return text

def yellow(text):
    print(f'gratient.yellow(text="{text}")')
    return text

def red(text):
    print(f'gratient.red(text="{text}")')
    return text