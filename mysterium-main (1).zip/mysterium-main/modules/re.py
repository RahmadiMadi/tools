print("import re")

def findall(pattern, string, flags=0):
    print(f"re.findall({pattern}, {string})")
    return ""

def split(pattern, string, maxsplit=0, flags=0):
    print(f"re.split({pattern}, {string})")
    return ""

def subn(pattern, repl, string, count=0, flags=0):
    print(f"re.subn({pattern}, {repl}, {string})")
    return ""

def sub(pattern, repl, string, count=0, flags=0):
    print(f"re.sub({pattern}, {repl}, {string})")
    return ""

def search(pattern, string, flags=0):
    print(f"re.search({pattern}, {string})")
    return ""

def fullmatch(pattern, string, flags=0):
    print(f"re.fullmatch({pattern}, {string})")
    return None

def match(pattern, string, flags=0):
    print(f"re.match({pattern}, {string})")
    return None

def finditer(pattern, string, flags=0):
    print(f"re.finditer({pattern}, {string})")
    return ""

def purge():
    print("re.purge()")
    return ""

def template(pattern, flags=0):
    print(f"re.template({pattern})")
    return ""

def escape(pattern):
    print(f"re.escape({pattern})")
    return ""

def compile(pattern, flags=0):
    pattern  = ""
    return ""

ASCII        = ""
IGNORECASE   = ""
LOCALE       = ""
UNICODE      = ""
MULTILINE    = ""
DOTALL       = ""
VERBOSE      = ""
TEMPLATE     = ""
DEBUG        = ""
print("import re")

def findall(pattern, string, flags=0):
    print(f"re.findall({pattern}, {string})")
    return ""

def split(pattern, string, maxsplit=0, flags=0):
    print(f"re.split({pattern}, {string})")
    return ""

def subn(pattern, repl, string, count=0, flags=0):
    print(f"re.subn({pattern}, {repl}, {string})")
    return ""

def sub(pattern, repl, string, count=0, flags=0):
    print(f"re.sub({pattern}, {repl}, {string})")
    return ""

def search(pattern, string, flags=0):
    print(f"re.search({pattern}, {string})")
    return ""

def fullmatch(pattern, string, flags=0):
    print(f"re.fullmatch({pattern}, {string})")
    return None

def match(pattern, string, flags=0):
    print(f"re.match({pattern}, {string})")
    return None

def finditer(pattern, string, flags=0):
    print(f"re.finditer({pattern}, {string})")
    return ""

def purge():
    print("re.purge()")
    return ""

def template(pattern, flags=0):
    print(f"re.template({pattern})")
    return ""

def escape(pattern):
    print(f"re.escape({pattern})")
    return ""

def compile(pattern, flags=0):
    pattern  = ""
    return ""

ASCII        = ""
IGNORECASE   = ""
LOCALE       = ""
UNICODE      = ""
MULTILINE    = ""
DOTALL       = ""
VERBOSE      = ""
TEMPLATE     = ""
DEBUG        = ""
