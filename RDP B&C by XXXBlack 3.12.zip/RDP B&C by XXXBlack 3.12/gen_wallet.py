from hdwallet import BIP44HDWallet
from hdwallet.cryptocurrencies import EthereumMainnet,BitcoinMainnet
from hdwallet.utils import generate_mnemonic, is_mnemonic
 
import json

def generate_wallets(MNEMONIC):
    # Choose strength 128, 160, 192, 224 or 256
    STRENGTH: int = 128  # Default is 128
    # Choose language english, french, italian, spanish, chinese_simplified, chinese_traditional, japanese or korean
    LANGUAGE: str = "english"  # Default is english
    # Generate new mnemonic words
    #MNEMONIC = "chair any believe stuff cradle lake eye toy grape crew plastic loud hero virus match convince icon goose lunch wage fatigue end supreme action"
     
    # Check mnemonic words
    assert is_mnemonic(mnemonic=MNEMONIC, language=LANGUAGE)
     
    # Initialize Litecoin mainnet HDWallet
    eth_wallet1: BIP44HDWallet = BIP44HDWallet(
        cryptocurrency=EthereumMainnet, account=0, change=False, address=0
    )
    eth_wallet2: BIP44HDWallet = BIP44HDWallet(
        cryptocurrency=EthereumMainnet, account=0, change=False, address=1
    )
    bit_wallet1: BIP44HDWallet = BIP44HDWallet(
        cryptocurrency=BitcoinMainnet, account=0, change=False, address=2
    )
    bit_wallet2: BIP44HDWallet = BIP44HDWallet(
        cryptocurrency=BitcoinMainnet, account=0, change=False, address=3
    )
    # Get Litecoin HDWallet from mnemonic
    eth_wallet1.from_mnemonic(
        mnemonic=MNEMONIC, language=LANGUAGE
    )
    eth_wallet2.from_mnemonic(
        mnemonic=MNEMONIC, language=LANGUAGE
    )
    bit_wallet1.from_mnemonic(
        mnemonic=MNEMONIC, language=LANGUAGE
    )
    bit_wallet2.from_mnemonic(
        mnemonic=MNEMONIC, language=LANGUAGE
    )
    # Print all Litecoin HDWallet information's

    return eth_wallet1,eth_wallet2,bit_wallet1,bit_wallet2

def print_wallets(phrase,f_out):
    eth1,eth2,bit1,bit2=generate_wallets(phrase)
    eth_addr1=eth1.p2pkh_address()
    eth_pk1=eth1.private_key()
    eth_addr2=eth2.p2pkh_address()
    eth_pk2=eth2.private_key()
    eth1.path()
    res=f'{"-"*24}\nAddressETH:{eth_addr1}\nAddressETH:{eth_addr2}\n' \
            f'PrivKeyETH:{eth_pk1}\nPrivKeyETH:{eth_pk2}\n{"-"*24}\n'

    bit_pk1=bit1.wif()
    bit_pk2=bit2.wif()
    bit_p2pkh_1=bit1.p2pkh_address()
    bit_p2pkh_2=bit2.p2pkh_address()
    bit_p2sh_1=bit1.p2sh_address()
    bit_p2sh_2=bit2.p2sh_address()
    bit_p2wpkh_1=bit1.p2wpkh_address()
    bit_p2wpkh_2=bit2.p2wpkh_address()

    res=res+f'AddressBTC:{bit_p2pkh_1}\n{bit_p2pkh_2}\n\np2pkh:{bit_pk1}\np2pkh:{bit_pk2}\n{"-"*24}\n' \
            f'AddressBTC:{bit_p2sh_1}\n{bit_p2sh_2}\n\np2sh:{bit_pk1}\np2sh:{bit_pk2}\n{"-"*24}\n' \
            f'AddressBTC:{bit_p2wpkh_1}\n{bit_p2wpkh_2}\n\np2wpkh:{bit_pk1}\np2wpkh:{bit_pk2}\n{"-"*24}\n'
    print(res,file=f_out)
