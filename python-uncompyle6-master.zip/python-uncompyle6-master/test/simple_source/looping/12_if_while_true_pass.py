# Python 3.3 pyclbr.py
# Note that Python 3 adds a lot of unnecessary "continues"
# and puts that in for "pass"
def _readmodule(g, token, path):
    for tokentype in g:
        if g:
            while True:
                if token:
                    token = 1
                elif token:
                    pass
                elif tokentype:
                    token = 7
            token = 10
