# Python 2.6 uses SETUP_LOOP while 2.7 doesn't
(e for s in (self, other) for e in s)
