# WP-XPL0IT
An automated BOT that completely controls your computer without you having to do anything while it exploits the site list you have prompted with a very fast speed.
<a href="#readme-before-starting">Read Usage (Required)</a>
![jatoch](https://user-images.githubusercontent.com/48758770/159566357-044cd208-7614-47d1-ae5b-b62a949e660f.png)


# README Before Starting
The installation is difficult.
### Very old wordpress websites wont work
- Only tested on Windows
- Should also work on Linux and MacOS<br>
### You HAVE to change the red marked screenshots to make this BOT WORK
But do not change the filenames only replace the screenshots with how your PC files look like
![changethem](https://user-images.githubusercontent.com/48758770/159557338-a6aeb6a6-964a-4145-9a88-c38b646c75f2.png)
### If a screenshot is not clear enough, the bot will not work. Make sure the screenshot is sharp enough.
Do not apply any other filenames, this will cause the bot to not work:
### The bot get the coordinates on where to click on the screen by the screenshot images, be sure they are sharp enough otherwise it miss clicks.
- ak.png =  Take a screenshot from a SPECIFIC SHELL file and replace the screenshot in ``bot_photos/ak.png`` with it. 
- desktop.png =  Take a screenshot from a how your Desktop logo looks like in file explorer and save it in ``bot_photos/desktop.png``
- exploit.png =  Take a screenshot from a how the WP-XPL0IT file looks like on your PC ``bot_photos/exploit.png``
<br><br>Do not forget to add the shell file to the directory in WP-XPL0IT root (``ak.png`` picture defines the bot on what file it needs to click,it will automaticly detect it screen x,y location and will be uploading it on the wordpress website). Be sure that the screenshot is sharp.<br>
<a href="#installation">After that, follow these installation instructions</a>
### While the bot is running do not move your mouse do not use your computer!
# Very Important
If a screenshot is not clear enough, the bot will not work. Make sure the screenshot is sharp enough.<br>
- The bot get the coordinates on where to click on the screen by the screenshot images, be sure they are sharp enough otherwise it miss clicks.

# Proof Videos
- <a href="https://www.youtube.com/watch?v=MRoR9SuKCfE">Uploading Auto Shell on Real Web Server</a>
- <a href="https://www.youtube.com/watch?v=gRa8VPdotDc">Proof Automatic Control</a>

# Installation
- Install Python3 on your windows <a href="https://www.python.org/downloads/">Download</a>
- Install Google Chrome on your Computer
- Execute the following commands in your CMD after installing Python3:
```shell
pip install selenium
pip install pyautogui
```
# Format
Revshow formatting is like:
```
https://website.com/wp-login.php#username@password
```

Default formatting is like:
```
A sites list with only:
https://website.com/wp-login.php

Userpass combo list txt with only:
user:pass
```
# Timeout
Timeout means how long should the bot retry to find an website element. Set 20sec or more if the website is very slow

# Credits
- Z3NTL3 : Developed the whole WP-XPL0IT BOT
- Bangladash Hacker Group: UBH Bypass Plugin
- B4tm4n: Exploit Shell
### WP-XPL0IT is only for EDUCATIONAL PURPOSES

# Run
```python wp-bot.py pcdelay_in_seconds`
// example:
python wp-bot.py 5

// Meaning the bot will once he controls your mouse it will wait everytime 5 seconds to scan and locate an element```
